README.txt
----------

Additional information relating to the build of design XPCB-006.

Design Ref : XPCB-006

Contact : Joe Golightly
Tel(UK) : 0117 9154285
Email   : joe@xmos.com
Address : XMOS Limited
          Venturers House
          King Street
          Bristol
          United Kingdom
          BS1 4PB

PCB Design tool : Mentor Graphics PADS2005 Flow. DxDesigner, PADS Layout.


Description of files included in XPCB-006-FAB.zip:

README.txt    This file.

contains the following gerber files for the design in RS-274-X format.
      
XPCB-006-Ln.pho     PCB Copper Layer (where n = layer number, 01=Top Side)
XPCB-006-SST.pho    Silkscreen Top
XPCB-006-SMT.pho    Solder Mask Top
XPCB-006-SMB.pho    Solder Mask Bottom
XPCB-006-SPT.pho    Solder Paste Top
XPCB-006-FAB.pho    Fabrication Instructions
XPCB-006-DRL.pho    Drill Diagram

contains the following drill data files for the design.

XPCB-006-NC.drl     NC Drill File (Excellon Format, metric (000.00), suppress trailing zeros, absolute coordinates)
XPCB-006-NC.rep     NC Drill Report (Sizes & Quantities)
XPCB-006-NC.lst     NC Drill List (Sizes & Coordinates)

